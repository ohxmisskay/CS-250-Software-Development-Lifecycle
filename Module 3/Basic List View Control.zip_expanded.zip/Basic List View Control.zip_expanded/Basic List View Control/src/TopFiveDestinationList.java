import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
                
                
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        
        
        
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 700);

        listModel = new DefaultListModel();
        

        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Japan | Take a stroll through the gardens of Tsu Castle.", new ImageIcon(getClass().getResource("/resources/Japan.jpg")));
        addDestinationNameAndPicture("2. Rome | Come Roman around the Colosseum.", new ImageIcon(getClass().getResource("/resources/Rome.jpg")));
        addDestinationNameAndPicture("3. Eygpt | Travel back in time with one of the world's earliest and greatest civilizations.", new ImageIcon(getClass().getResource("/resources/Egypt.jpg")));
        addDestinationNameAndPicture("4. China | Accomplish walking the longest man made structure, the Great Wall of China.", new ImageIcon(getClass().getResource("/resources/China.jpg")));
        addDestinationNameAndPicture("5. Germany | Find your inner peace with the Brandenburg Gate.", new ImageIcon(getClass().getResource("/resources/Germany.jpg")));
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setCellRenderer(renderer);

        getContentPane().add(scrollPane, BorderLayout.CENTER);
        
        
        // Sets Label with blue background, white font, and set to bottom of the border layout
        JLabel lblNewLabel = new JLabel("SNHU - CS-250 Software Development Lifecycle - Developed by Winnie Kwong");
        add(lblNewLabel, BorderLayout.SOUTH);
        lblNewLabel.setForeground(new Color(255, 255, 255));
    	getContentPane().setBackground(new Color(132, 193, 255));
        
        
    }
   

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
            
            // Changes the background color to blue and the font to white when selected
            setForeground(new Color(255,255,255));
            setBackground(new Color(132, 193, 255));
            
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
            
            // Changes the font color to blue
            setForeground(new Color(132, 193, 255));
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}